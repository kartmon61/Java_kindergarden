package app;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.Inet4Address;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import dao.AdminDao;
import dao.StudentDao;
import service.AdminService;
import service.AdminServiceImpl;
import service.StudentService;
import service.StudentServiceImpl;

public class LoginGui {

	// 멤버 변수 선언

	public static String adminID; // 관리자 아이디
	static String adminPW;
	public static int studentID; //학생 아이디
	AdminDao dao = new AdminDao();
	AdminService ads = new AdminServiceImpl(dao);
	JFrame f;
	JButton bLogin;
	TextField tfId,tfPw;
	JTabbedPane tPane;
	JPanel adPanel;
	JPanel paPanel;
	JTextField ptfId,ptfId1;
	JButton pLogin;
	JButton bRegister;
	StudentDao dao1 = new StudentDao();
	StudentService service = new StudentServiceImpl(dao1);

	//이미지 삽입
	ImageIcon ic = new ImageIcon("src\\app\\IMG_4643_5.PNG");
	JLabel imgic = new JLabel(ic);
	
	LoginGui(){
		f = new JFrame("프로그램 로그인");
		bLogin = new JButton("로그인");

		tfId = new TextField();
		tfPw = new TextField();
		adminID = null;
		adminPW = null;
		tPane = new JTabbedPane();
		adPanel = new JPanel();
		paPanel = new JPanel();
		ptfId = new JTextField();
		ptfId1 = new JTextField();

		pLogin = new JButton("로그인");
		bRegister = new JButton("회원가입");

	} //end of loginGui


	//화면 붙이기 및 출력

	void addLayout() {
		adPanel.setLayout(new BorderLayout());
		paPanel.setLayout(new BorderLayout());
		JPanel p = new JPanel();
		p.setLayout(new GridLayout(2,2));
		p.add(new JLabel("아이디"));
		p.add(tfId);
		p.add(new JLabel("비밀번호"));
		p.add(tfPw);
		p.setBackground(new Color(255,233,147));


		JPanel p1 = new JPanel();
		p1.setLayout(new GridLayout(1,2));
		p1.add(p);
		p1.add(bLogin);
		p1.add(bRegister);
		p1.setBackground(new Color(255,233,147));


		JPanel p2 = new JPanel();
		p2.setLayout(new GridLayout(2,1));
		p2.add(p1);
		p2.setBackground(new Color(255,233,147));

		JPanel p3 = new JPanel();
		p3.setLayout(new GridLayout(2,2));
		p3.add(new JLabel("학원ID"));
		p3.add(ptfId1);
		p3.add(new JLabel("학생ID"));
		p3.add(ptfId);
		p3.setBackground(new Color(255,233,147));



		JPanel p4 = new JPanel();
		p4.setLayout(new GridLayout(1,2));
		p4.add(p3);
		p4.add(pLogin);
		p4.setBackground(new Color(255,233,147));


		JPanel p5 = new JPanel();
		p5.setLayout(new GridLayout(2,1));
		p5.add(p4);
		p5.setBackground(new Color(255,233,147));

		JPanel p6 = new JPanel();
		p6.setLayout(new BorderLayout());
		p6.add(imgic);
		f.add(p6, BorderLayout.NORTH);
		p6.setBackground(new Color(255,233,147));


		paPanel.add(p5,BorderLayout.SOUTH);
		adPanel.add(p2,BorderLayout.SOUTH);
		paPanel.setBackground(new Color(255,233,147));
		adPanel.setBackground(new Color(255,233,147));
		f.setBackground(new Color(255,233,147));
		f.setSize(400, 400);
		f.setResizable(false);
		f.setBackground(new Color(255,233,147));
		f.setVisible(true);
		tPane.addTab("관리자 로그인", adPanel);
		tPane.addTab("학부모 로그인", paPanel);
		//      tPane.setBackground(new Color(255,233,147));
		f.add(tPane);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// 관리자 로그인 액션리스너
		bLogin.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				if (ads.checkLogIn(tfId.getText(), tfPw.getText())) {
					adminID = tfId.getText();
					adminPW = tfPw.getText();
					DbGui ui = new DbGui();
					ui.addLayout();
					ui.eventProc();
					f.setVisible(false);

				}
				else JOptionPane.showMessageDialog(null, "아이디 비밀번호 확인 바랍니다");
			}
		});//end of bLogin.addActionListener

		//학부모 로그인 액션리스너
		pLogin.addActionListener(new ActionListener() {


			public void actionPerformed(ActionEvent e) {
				if(ads.checkpLogIn(ptfId1.getText(), Integer.parseInt(ptfId.getText()))) {
					adminID = ptfId1.getText();
					studentID = Integer.parseInt(ptfId.getText());
					ParentGui pg = new ParentGui();
					pg.addLayout();
					f.setVisible(false);
				}
				else JOptionPane.showMessageDialog(null, "학생ID, 학원ID를 확인해주세요");

			}
		});//end of pLogin.addActionListener

		bRegister.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {



				ads.insertAdmin(tfId.getText(), tfPw.getText());

				JOptionPane.showMessageDialog(null, "입력되었습니다.");


			}
		});


	} //end of addLayout



	public static void main(String[] args) {
		LoginGui lg = new LoginGui();
		lg.addLayout();



	} // end of main

}