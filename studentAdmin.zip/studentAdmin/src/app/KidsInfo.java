package app;
//tfName,tfGender,tfAge,tfBirth,tfSpecial,tfMom,tfMomPh,tfHome,tfInfo
public class KidsInfo {
	String id,name,gender,age,birth,special,mom,momph,home,info;
	
	public KidsInfo() {
		
	}
//생성자 함수
	public KidsInfo(String id,String name, String gender, String age, String birth, String special, String mom, String momph,
			String home, String info) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.birth = birth;
		this.special = special;
		this.mom = mom;
		this.momph = momph;
		this.home = home;
		this.info = info;
	}

	
	
	//getter , setter
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getSpecial() {
		return special;
	}

	public void setSpecial(String special) {
		this.special = special;
	}

	public String getMom() {
		return mom;
	}

	public void setMom(String mom) {
		this.mom = mom;
	}

	public String getMomph() {
		return momph;
	}

	public void setMomph(String momph) {
		this.momph = momph;
	}

	public String getHome() {
		return home;
	}

	public void setHome(String home) {
		this.home = home;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}
	
	
	
	//to String
	@Override
	public String toString() {
		return "   [ 학생 ID= "+id+"이름=" + name + ", 성별= " + gender + ", 나이= " + age + ", 생년월일= " + birth +  ", 거주지= " + home +", 특이사항= "
				+ special + ", 보호자= " + mom + ", 보호자연락처= " + momph + ", 기타정보="  + info + "]"+"\n";
	}
	
	
	
	
	
	

	
	

}
