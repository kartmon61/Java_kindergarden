package app;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import dao.StudentDao;
import service.StudentService;
import service.StudentServiceImpl;
import vo.StudentVo;

public class DbGui{

	// 멤버 변수 선언
	AttendGui ag = new AttendGui();
	JFrame f;
	JButton bInsert,bModify,bDelete,bCheck,bExit;
	Font font;
	   JLabel stid, stname, stgen, stage, stbirth, sthome, momname, momcall, stsp, something;
	/*JTextArea ta;*/
	JTabbedPane tPane;
	JTextField tfId, tfName,tfGender,tfAge,tfBirth,tfSpecial,tfMom,tfMomPh,tfHome,tfInfo;
	ArrayList<StudentVo> list = new ArrayList<>();
	//학생 선택 스트링
	//	String []name = {"이진호"};
	JList<String> nameList;
	StudentDao dao = new StudentDao();
	StudentService service = new StudentServiceImpl();
	ListHdlr lh = new ListHdlr();
	DefaultListModel<String> dlm;
	

	//객체 생성
	DbGui(){
		   //우석스터치*************************************************
		   
	      
	      stid =new JLabel("학생 ID",new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      stname= new JLabel("학생 이름", new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      stgen= new JLabel("학생 성별", new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      stage= new JLabel("학생 나이", new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      stbirth= new JLabel("학생 생일", new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      sthome= new JLabel("거주지", new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      momname= new JLabel("학생 보호자", new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      momcall= new JLabel("보호자 연락처", new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      stsp= new JLabel("학생 특이사항", new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      something= new JLabel("오늘의 특이사항", new ImageIcon("src\\app\\진짜진짜새싹병아리2.png"), JLabel.CENTER);
	      
		f = new JFrame("신상 정보 관리");
		bInsert = new JButton("학생정보 등록");
		bModify = new JButton("학생정보 수정");
		bDelete = new JButton("학생정보 삭제");
		bCheck = new JButton("학생정보 입력란 삭제");
		bExit = new JButton("종료");
		/*		ta = new JTextArea();*/
		tfId = new JTextField(20);
		tfName = new JTextField(20);
		tfAge = new JTextField(20);
		tfGender = new JTextField(20);
		tfBirth = new JTextField(20);
		tfHome = new JTextField(20);
		tfMom = new JTextField(20);
		tfMomPh = new JTextField(20);
		tfSpecial = new JTextField(20);
		tfInfo = new JTextField(20);
		nameList = new JList<String>();
		tPane = new JTabbedPane();
		ag = new AttendGui();
		dlm = new DefaultListModel<>();
		font = new Font("배달의민족 한나는 열한살", Font.PLAIN, 15);
		
	} //End of DbGui

	
	//ta 생성 및 이미지 아이콘 삽입
	final ImageIcon imageIcon = new ImageIcon("src\\app\\가자2.png");
	JTextArea ta = new JTextArea() {
		Image image = imageIcon.getImage();


		Image nomalImage = imageIcon.getImage();                                              
		{
			setOpaque(false);
		}






		public void paint(Graphics g) {
			g.drawImage(nomalImage, 0, 0, this);
			super.paint(g);
		}
	};//end of JTextArea
	

	//화면 붙이기 및 출력
	void addLayout() {

		f.setLayout(new BorderLayout());
		JPanel mPanel = new JPanel(new BorderLayout());

		JPanel p2 = new JPanel();
		p2.setLayout(new BorderLayout());
		p2.add(ta,new BorderLayout().CENTER);
		p2.setBackground(new Color(255,246,213));
		getList();
		ta.setLineWrap(true);
		//학생 리스트 선택 창

		nameList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		//	      nameList.setSelectedIndex(0);
		nameList.setVisibleRowCount(30);
		
		JScrollPane nameListScrollPane = new JScrollPane(nameList);  
		p2.add(nameListScrollPane,new BorderLayout().EAST);
		mPanel.add(p2, new BorderLayout().CENTER);



		JPanel p = new JPanel();

/*		p.setLayout(new GridLayout(10, 2));
		p.add(new JLabel("학생 Id"));
		p.add(tfId);
		p.add(new JLabel("이름"));
		p.add(tfName);
		p.add(new JLabel("성별"));
		p.add(tfGender);
		p.add(new JLabel("나이"));
		p.add(tfAge);
		p.add(new JLabel("생년월일"));
		p.add(tfBirth);
		p.add(new JLabel("거주지"));
		p.add(tfHome);
		p.add(new JLabel("보호자 이름"));
		p.add(tfMom);
		p.add(new JLabel("보호자 연락처"));
		p.add(tfMomPh);
		p.add(new JLabel("특이사항"));
		p.add(tfSpecial);
		p.add(new JLabel("오늘의 특이사항"));
		p.add(tfInfo);
		p.setBackground(new Color(255,233,147));*/
		
		   p.setLayout(new GridLayout(10, 2));
		      p.add(stid);
		      stid.setFont(font);
		      p.add(tfId);
		      
		      p.add(stname);
		      stname.setFont(font);
		      p.add(tfName);
		      
		      p.add(stgen);
		      p.add(tfGender);
		      stgen.setFont(font);
		      
		      p.add(stage);
		      p.add(tfAge);
		      stage.setFont(font);
		      
		      p.add(stbirth);
		      p.add(tfBirth);
		      stbirth.setFont(font);
		      
		      p.add(sthome);
		      p.add(tfHome);
		      sthome.setFont(font);
		      
		      p.add(momname);
		      p.add(tfMom);
		      momname.setFont(font);
		      
		      p.add(momcall);
		      p.add(tfMomPh);
		      momcall.setFont(font);
		      
		      p.add(stsp);
		      p.add(tfSpecial);
		      stsp.setFont(font);
		      
		      p.add(something);
		      p.add(tfInfo);
		      something.setFont(font);
		      
		      p.setBackground(new Color(255,233,147));
		


		mPanel.add(p, new BorderLayout().EAST);



		JPanel p1 = new JPanel();
		p1.setLayout(new GridLayout(1, 5));
		p1.add(bInsert);
		p1.add(bModify);
		p1.add(bDelete);
		p1.add(bCheck);
		p1.add(bExit);
		p1.setBackground(new Color(255,233,147));
		mPanel.add(p1,new BorderLayout().SOUTH);
		mPanel.setBackground(new Color(255,233,147));
		tPane.addTab("학생인적관리", mPanel);
		tPane.addTab("학생출결관리", ag.getApanel());
		tPane.addChangeListener(new ChangeListener() {
			
			public void stateChanged(ChangeEvent e) {
				ag.getList();
				getList();
			}
		});
		f.add(tPane);
		f.setSize(1500, 1000);
		f.setVisible(true);
		f.setBackground(new Color(255,233,147));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}// End of addLayout 



	//이벤트 함수
	void eventProc() {
		//이벤트 핸들러 객체 생성

		BtnHdlr bh = new BtnHdlr();
		
		
		nameList.addListSelectionListener(lh);
		//이벤트 발생 컴포넌트 연결

		bInsert.addActionListener(bh);
		bModify.addActionListener(bh);
		bCheck.addActionListener(bh);
		bDelete.addActionListener(bh);
		bExit.addActionListener(bh);






	} //end of eventProc
	
	//이벤트 리스트 핸들러
	class ListHdlr implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent e) {
			if (!e.getValueIsAdjusting()) {
				ta.setText(null);
				showData();
				ArrayList<StudentVo> temp = (ArrayList<StudentVo>)service.searchStudent((String)nameList.getSelectedValue());
				Iterator<StudentVo> ii = temp.iterator();
				while (ii.hasNext()) {
					StudentVo studentVo = (StudentVo) ii.next();
					tfId.setText(String.valueOf(studentVo.getStudentID()));
					tfName.setText(studentVo.getName());
					tfAge.setText(String.valueOf(studentVo.getAge()));
					tfGender.setText(studentVo.getGender());
					tfBirth.setText(studentVo.getBirth());
					tfHome.setText(studentVo.getHome());
					tfMom.setText(studentVo.getParentName());
					tfMomPh.setText(studentVo.getParentPhone());
					tfSpecial.setText(studentVo.getSpecial());
					tfInfo.setText(studentVo.getInfo());
				}
			}
		}
		
	}//end of ListHdlr
	
	//리스트 보여주기
	public void getList() {
		dlm.removeAllElements();
		ArrayList<StudentVo> temp = new ArrayList<>();
		temp = (ArrayList<StudentVo>)service.getStudents();
		Iterator<StudentVo> ii = temp.iterator();
		while (ii.hasNext()) {
			StudentVo studentVo = (StudentVo) ii.next();
			if (dlm.contains(studentVo.getName())) continue;
			dlm.addElement(studentVo.getName());
		}

		nameList.setModel(dlm);
	}//end of getList

	
	
	//이벤트 버튼 핸들러 
	class BtnHdlr implements ActionListener{

		public void actionPerformed(ActionEvent e) {
			JButton btn = (JButton)e.getSource();
			//등록 버튼
			if(btn == bInsert) {
				insertData();
				clearTextField();
				showData();
				JOptionPane.showMessageDialog(null, "신상정보를 등록합니다");
			}
			//수정 버튼
			else if (btn == bModify) {
				modifyData();
				clearTextField();
				showData();
				JOptionPane.showMessageDialog(null, "신상정보를 수정합니다");
			}
			//삭제 버튼
			else if (btn == bDelete) {
				deleteData();
				clearTextField();
				showData();
				JOptionPane.showMessageDialog(null, "신상정보를 삭제합니다");
			}
			//확인 버튼
			else if(btn == bCheck) {
				clearTextField();
				
				
			}
			//종료 버튼
			else if(btn == bExit) {
				JOptionPane.showMessageDialog(null, "신상 정보 관리를 종료합니다");
				System.exit(0);
			}

		}


	}//end of BtnHdlr
	
	

	//텍스트필드 제거
	void clearTextField() {
		tfId.setText(null);
		tfName.setText(null);
		tfAge.setText(null);
		tfGender.setText(null);
		tfBirth.setText(null);
		tfHome.setText(null);
		tfMom.setText(null);
		tfMomPh.setText(null);
		tfSpecial.setText(null);
		tfInfo.setText(null);
	}//end of clearTextField

	//데이터 보여주기
	void showData() {
		ta.setText("  =======================================<학>=<생>=<정>=<보>========================================="+"\n");
		list = (ArrayList<StudentVo>)service.getStudents();
		Iterator<StudentVo> ii = list.iterator();
		while (ii.hasNext()) {
			StudentVo studentVo = (StudentVo) ii.next();
			ta.append(studentVo.toString() + "\n");
			
		}

	}//end of showData



	//데이터 추가
	void insertData() {
		StudentVo kds = new StudentVo();

		kds.setStudentID(Integer.parseInt(tfId.getText()));
		kds.setName(tfName.getText());
		kds.setAge(Integer.parseInt(tfAge.getText()));
		kds.setGender(tfGender.getText());
		kds.setBirth(tfBirth.getText());
		kds.setHome(tfHome.getText());
		kds.setParentName(tfMom.getText());
		kds.setParentPhone(tfMomPh.getText());
		kds.setSpecial(tfSpecial.getText());
		kds.setInfo(tfInfo.getText());

		try {
			service.insertStudent(Integer.parseInt(tfId.getText()), "0000/00/00", tfGender.getText(),
					Integer.parseInt(tfAge.getText()), tfBirth.getText(),
					tfMom.getText(), tfName.getText(),
					tfMomPh.getText(), tfSpecial.getText(), tfInfo.getText(), tfHome.getText());
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showConfirmDialog(null, "입력사항을 확인하세요");
		}
		nameList.removeListSelectionListener(lh);
		dlm.addElement(kds.getName());	
		nameList.setModel(dlm);
		nameList.addListSelectionListener(lh);
		ag.getList();
		
		

	}//end of insertData


	//데이터 변경
	void modifyData() {

		try {
			service.updateStudent(Integer.parseInt(tfId.getText()), tfGender.getText(),
					Integer.parseInt(tfAge.getText()), tfBirth.getText(),
					tfMom.getText(), tfName.getText(),
					tfMomPh.getText(), tfSpecial.getText(), tfInfo.getText(), tfHome.getText());
		} catch (Exception e) {
			JOptionPane.showConfirmDialog(null, "수정사항을 확인하세요");
		}
		nameList.removeListSelectionListener(lh);
		getList();
		ag.getList();
		nameList.addListSelectionListener(lh);
	}//end of modifyData




	//데이터 삭제
	synchronized void deleteData() {

		StudentVo vo = service.searchStudent(Integer.parseInt(tfId.getText()));
		if(dlm.contains(vo.getName())) {
			nameList.removeListSelectionListener(lh);
			dlm.removeElement(vo.getName());
			nameList.setModel(dlm);
			nameList.addListSelectionListener(lh);
		}
		service.deleteStudent(Integer.parseInt(tfId.getText()));
		ag.tfId.setText(null);
		ag.tfName.setText(null);
//		ag.getList();


	}//end of deleteData

} //End of DbGui
