package app;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import dao.StudentDao;
import service.StudentService;
import service.StudentServiceImpl;
import vo.StudentVo;
public class AttendGui {

	// 멤버 변수 선언
	SimpleDateFormat date = new SimpleDateFormat("yyyy/MM/dd");
	SimpleDateFormat time = new SimpleDateFormat("hh:mm:ss a");
	StudentDao dao = new StudentDao();
	StudentService service = new StudentServiceImpl(dao);
	JFrame f;
	JList<String> nameList;
	JButton bSearch,bAttend;
	JTextField tfName, tfId;
	JPanel aPanel;
	Font font;
	DefaultListModel<String> dlm;
	JTextArea ta1, ta2, ta;
	ListHdlr lh = new ListHdlr();
	JButton bOut;
	JLabel label1, label2, label3, label4;


	// 객체 생성
	AttendGui(){
		f = new JFrame("출석 관리");
		bSearch = new JButton("검색");
		bAttend = new JButton("등원");
		bOut = new JButton("하원");
		tfName = new JTextField(10);
		tfId = new JTextField(10);
		/*	ta = new JTextArea();*/
		nameList = new JList<String>();
		aPanel = new JPanel();
		dlm = new DefaultListModel<>();
		getList();

		font = new Font("배달의민족 한나는 열한살", Font.PLAIN, 15);

		label1 = new JLabel("    학생 검색");
		label2 = new JLabel("ID");
		label3 = new JLabel("학생 이름");
		
	}


	//화면 붙이기 및 출력
	public JPanel getApanel() {
		aPanel.setLayout(new BorderLayout());
		//왼쪽 패널
		JPanel p = new JPanel();
		p.setLayout(new BorderLayout());
		p.setBackground(new Color(255,233,147));
		getList();
		//학생 검색 패널
		JPanel p1 = new JPanel();
		p1.setLayout(new GridLayout(14, 1));
/*		p1.add(new JLabel("    학생 검색"));*/
		/*		p1.add(new JPanel());*/
	      p1.add(label1);
	      label1.setFont(font);
/*		p1.add(new JLabel("ID"));
		p1.add(tfId);
		p1.add(new JLabel("학생 이름"));
		p1.add(tfName);*/
	      p1.add(label2);
	      label2.setFont(font);
	      p1.add(tfId);
	      p1.add(label3);
	      label3.setFont(font);
	      p1.add(tfName);

		/*	p1.add(new JPanel());*/
		p1.add(bSearch);
		JPanel p4 = new JPanel();
		p4.setBackground(new Color(255,233,147));
		p1.add(p4);	
		p1.add(bAttend);
		p1.add(bOut);
		p1.setBackground(new Color(255,233,147));

		JPanel p2 = new JPanel();
		p2.setLayout(new GridLayout(3,1));
		p2.add(p1);
		/*		p2.add(new JPanel());
		p2.add(new JPanel());*/
		p2.setBackground(new Color(255,233,147));

		p.add(p2,new BorderLayout().CENTER);


		JPanel p3 = new JPanel();
		p3.setLayout(new BorderLayout());
		nameList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		nameList.setVisibleRowCount(30); 

		JScrollPane nameListScrollPane = new JScrollPane(nameList);  
		p3.add(nameListScrollPane,new BorderLayout().EAST);
		p3.add(new JLabel("  출결 관리  "),new BorderLayout().WEST);
		p3.add(p2,new BorderLayout().CENTER);
		p3.setBackground(new Color(255,233,147));

		aPanel.add(p3,new BorderLayout().WEST);

		JPanel p0 = new JPanel();
		p0.setLayout(new GridLayout(3, 1));

		final ImageIcon imageIcon = new ImageIcon("src\\app\\가자3.png");
		JPanel p10 = new JPanel();
		p10.setLayout(new BorderLayout());
		p10.add(new JLabel("등하원정보"),BorderLayout.NORTH);
		ta = new JTextArea() {
			Image image = imageIcon.getImage();


			Image nomalImage = imageIcon.getImage();                                              
			{
				setOpaque(false);
			}



			public void paint(Graphics g) {
				g.drawImage(nomalImage, 0, 0, this);
				super.paint(g);
			}
		}; // end of ta
		p10.add(ta,BorderLayout.CENTER);
		p10.setBackground(new Color(255,246,213));
		JPanel p11 = new JPanel();
		p11.setLayout(new BorderLayout());
		p11.add(new JLabel("오늘 등원 시간"),BorderLayout.NORTH);
		p11.setBackground(new Color(255,246,213));
		ta1 = new JTextArea() {
			Image image = imageIcon.getImage();


			Image nomalImage = imageIcon.getImage();                                              
			{
				setOpaque(false);
			}



			public void paint(Graphics g) {
				g.drawImage(nomalImage, 0, 0, this);
				super.paint(g);
			}
		}; // end of ta1

		p11.add(ta1,BorderLayout.CENTER);

		JPanel p12 = new JPanel();
		p12.setLayout(new BorderLayout());
		p12.add(new JLabel("오늘 하원 시간"),BorderLayout.NORTH);
		p12.setBackground(new Color(255,246,213));
		ta2 = new JTextArea() {
			Image image = imageIcon.getImage();


			Image nomalImage = imageIcon.getImage();                                              
			{
				setOpaque(false);
			}



			public void paint(Graphics g) {
				g.drawImage(nomalImage, 0, 0, this);
				super.paint(g);
			}
		}; // end of ta2

		p12.add(ta2,BorderLayout.CENTER);

		p0.add(p10);
		p0.add(p11);
		p0.add(p12);

		nameList.addListSelectionListener(lh);
		aPanel.add(p0,new BorderLayout().CENTER);
		aPanel.setBackground(new Color(255,246,213));



		bSearch.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				ta.setText("=================학생 출석========================\n");
				ArrayList<StudentVo> list = new ArrayList<>();
				list = (ArrayList<StudentVo>)service.searchAttend(Integer.parseInt(tfId.getText()));
				Iterator<StudentVo> ii = list.iterator();
				while (ii.hasNext()) {
					StudentVo studentVo = (StudentVo) ii.next();
					ta.append("학생ID: " + studentVo.getStudentID() +
							" 학생 이름: " + studentVo.getName() +
							" 학생 출석: " + studentVo.getAttend() + "\n");
				}
			}
		});

		bAttend.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				StudentVo vo = new StudentVo();
				vo = service.searchStudent(Integer.parseInt(tfId.getText()));
				try {
					service.insertStudent(vo.getStudentID(), date.format(new Date())+"/"+ time.format(new Date()), vo.getGender(), vo.getAge(), vo.getBirth(), vo.getParentName(), vo.getName(), vo.getParentPhone(), vo.getSpecial(), vo.getInfo(), vo.getHome());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				ta1.setText("=================등원 시간========================\n");
				ta1.append("학생ID: " + vo.getStudentID() +
						" 학생 이름: " + vo.getName() +
						" 학생 출석: " + date.format(new Date())+"일      "+ time.format(new Date()) + "입니다.\n");
			}
		});

		bOut.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				StudentVo vo = new StudentVo();
				vo = service.searchStudent(Integer.parseInt(tfId.getText()));
				try {
					service.insertStudent(vo.getStudentID(), date.format(new Date())+"일      "+ time.format(new Date()), vo.getGender(), vo.getAge(), vo.getBirth(), vo.getParentName(), vo.getName(), vo.getParentPhone(), vo.getSpecial(), vo.getInfo(), vo.getHome());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				ta2.setText("=================하원 시간========================\n");
				ta2.append("학생ID: " + vo.getStudentID() +
						" 학생 이름: " + vo.getName() +
						" 학생 출석: " + date.format(new Date())+"일      "+ time.format(new Date()) + "입니다.\n");
			}

		});

		//		f.setSize(1000, 1000);
		//		f.setVisible(true);
		return aPanel;
		//		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}//end of add Layout

	public void getList() {
		nameList.removeListSelectionListener(lh);
		ArrayList<StudentVo> temp = new ArrayList<>();
		temp = (ArrayList<StudentVo>)service.getStudents();

		Iterator<StudentVo> ii = temp.iterator();
		dlm.removeAllElements();
		while (ii.hasNext()) {
			StudentVo studentVo = (StudentVo) ii.next();
			if (dlm.contains(studentVo.getName())) continue;
			dlm.addElement(studentVo.getName());
		}
		
		nameList.setModel(dlm);
		nameList.addListSelectionListener(lh);

	}

	class ListHdlr implements ListSelectionListener {

		public void valueChanged(ListSelectionEvent e) {
			if (!e.getValueIsAdjusting()) {
				ta.setText("  =======================================<학>=<생>=<정>=<보>========================================="+"\n");
				ArrayList<StudentVo> temp = (ArrayList<StudentVo>)service.searchStudent((String)nameList.getSelectedValue());
				Iterator<StudentVo> ii = temp.iterator();
				while (ii.hasNext()) {
					StudentVo studentVo = (StudentVo) ii.next();
					tfName.setText(studentVo.getName());
					tfId.setText(String.valueOf(studentVo.getStudentID()));
				}
				ArrayList<StudentVo> list = (ArrayList<StudentVo>)service.searchAttend((String)nameList.getSelectedValue());
				Iterator<StudentVo> tt = list.iterator();
				while (tt.hasNext()) {
					StudentVo studentVo = (StudentVo) tt.next();
					tfName.setText(studentVo.getName());
					tfId.setText(String.valueOf(studentVo.getStudentID()));
					ta.append("학생ID: " + studentVo.getStudentID() +
							" 학생 이름: " + studentVo.getName() +
							" 학생 출석: " + studentVo.getAttend() + "\n");
				}
			}
		}

	}
}
