package app;

import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;

import dao.StudentDao;
import service.StudentService;
import service.StudentServiceImpl;
import vo.StudentVo;

public class ParentGui {


	//변수 선언
	JFrame f;
	JTextField tfId, tfName,tfAttendIn, tfAttendOut;
	JTextArea taSpecial;
	JPanel aPanel;
	StudentDao dao = new StudentDao();
	StudentService service = new StudentServiceImpl(dao);

	Font f1;
	   
	   JLabel stid = new JLabel("학생 ID");
	   JLabel stname = new JLabel("학생 이름");
	   JLabel stcome = new JLabel("등원 시간");
	   JLabel stback = new JLabel("하원 시간");
	   JLabel stsp = new JLabel("특이 사항");



	//객체 생성
	ParentGui(){

		f1 = new Font("배달의민족 한나는 열한살", Font.PLAIN, 15);
		
		f = new JFrame("부모님 보여주기");
		tfId = new JTextField();
		tfName = new JTextField();
		tfAttendIn = new JTextField();
		tfAttendOut = new JTextField();
		taSpecial = new JTextArea();

		


		



		aPanel = new JPanel();
	} // end of ParentGui


	//화면 붙이기 및 출력
	void addLayout() {
//		f.setLayout(new BorderLayout());
//		aPanel.setLayout(new BorderLayout());
//		JPanel p = new JPanel();
//		p.setLayout(new GridLayout(2, 4)); 
//		p.add(new JLabel("학생 ID"));
//		p.add(tfId);
//		p.add(new JLabel("학생 이름"));
//		p.add(tfName);
//		p.add(new JLabel("등원 시간"));
//		p.add(tfAttendIn);
//		p.add(new JLabel("하원 시간"));
//		p.add(tfAttendOut);
//		
//		
//		
//		
//		aPanel.add(p,BorderLayout.NORTH); 
//		getAttend();
//		JPanel p1 = new JPanel();
//		p1.setLayout(new BorderLayout());
//		p1.add(new JLabel("특이 사항"), BorderLayout.WEST);
		
	      f.setLayout(new BorderLayout());
	      aPanel.setLayout(new BorderLayout());
	      JPanel p = new JPanel();
	      p.setLayout(new GridLayout(2, 4)); 
	      p.add(stid);
	      getAttend();
	      stid.setFont(f1);
	      p.add(tfId);
	      p.add(stname);
	      stname.setFont(f1);
	      p.add(tfName);
	      p.add(stcome);
	      stcome.setFont(f1);
	      p.add(tfAttendIn);
	      p.add(stback);
	      stback.setFont(f1);
	      p.add(tfAttendOut);



	      aPanel.add(p,BorderLayout.NORTH); 
	      p.setBackground(new Color(255,222,101));
	      JPanel p1 = new JPanel();
	      p1.setLayout(new BorderLayout());
	      p1.add(stsp, BorderLayout.WEST);
	      stsp.setFont(f1);
	      
	    taSpecial.setBackground(new Color(255,255,218));  
		p1.add(taSpecial, BorderLayout.CENTER);
		p1.setBackground(new Color(255, 231, 143));
		aPanel.add(p1, BorderLayout.CENTER);
		f.add(p,BorderLayout.NORTH);
		f.add(p1,BorderLayout.CENTER);
		f.setSize(1000, 400);
		f.setVisible(true);
		f.setBackground(new Color(255,233,147));
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


	}//end of addLayout
	void getAttend() {
		StudentVo vo = new StudentVo();
		
		vo = service.searchStudent(LoginGui.studentID);
		tfName.setText(vo.getName());
		tfId.setText(String.valueOf(vo.getStudentID()));
		taSpecial.setText(vo.getInfo());
		ArrayList<StudentVo> list = (ArrayList<StudentVo>)service.searchDayAttend(LoginGui.studentID);
		if (list.size() < 1) {
			tfAttendIn.setText("등원하지 않았습니다");
			return;
		}
		tfAttendIn.setText(list.get(0).getAttend() + "에 등원 하였습니다\n");
		if (list.size() < 2) {
			tfAttendOut.setText("하원하지 않았습니다");
			return;
		}
		tfAttendOut.setText(list.get(1).getAttend() + "에 하원 하였습니다\n");
	}
	

}