package service;

import java.util.List;

import vo.StudentVo;

public interface StudentService {

	public int insertStudent(int studentID, String attend, String gender, int age, 
			String birth, String parentName, String name, String parentPhone, String special, String info, String home) throws Exception; //학생 정보 삽입
	public int deleteStudent(int studentID); // 학생정보 삭제
	public List<StudentVo> searchStudent(String name);
	public StudentVo searchStudent(int studentID);
	public List<StudentVo> getStudents();
	public List<StudentVo> searchAttend(int studentID);
	public int updateStudent(int studentID, String gender, int age, 
			String birth, String parentName, String name, String parentPhone, String special, String info, String home) throws Exception;
	public List<StudentVo> searchAttend(String name);
	public List<StudentVo> searchDayAttend(int studentID);
	
}
