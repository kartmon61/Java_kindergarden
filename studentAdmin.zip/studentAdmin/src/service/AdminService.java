package service;

public interface AdminService {
	public boolean checkLogIn(String adminID, String adminPW);// 관리자 로그인 체크
	public int insertAdmin(String adminID, String adminPW); //관리자 회원가입
	public boolean checkpLogIn(String adminID, int studentID);
//	public void deleteAdmin(); //나중에 회원탈퇴 만들시 구현
}
