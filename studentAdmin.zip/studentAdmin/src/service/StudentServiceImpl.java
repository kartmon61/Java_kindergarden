package service;

import java.util.List;

import dao.StudentDao;
import vo.StudentVo;

public class StudentServiceImpl implements StudentService{

	private StudentDao dao = new StudentDao();
	
	
	
	public StudentServiceImpl() {
		super();
	}

	public StudentServiceImpl(StudentDao dao) {
		super();
		this.dao = dao;
	}

	public StudentDao getDao() {
		return dao;
	}

	public void setDao(StudentDao dao) {
		this.dao = dao;
	}

	public int insertStudent(int studentID, String attend, String gender, int age, String birth, String parentName, String name, String parentPhone, String special, String info, String home) throws Exception {
		
		return dao.insertStudent(studentID, attend, gender, age, birth, parentName, name, parentPhone, special, info, home);
	}

	public int deleteStudent(int studentID) {
		return dao.deleteStudent(studentID);
	}

	public List<StudentVo> searchStudent(String title) {
		return dao.searchStudent(title);
	}

	public StudentVo searchStudent(int studentID) {
		return dao.searchStudent(studentID);
	}

	public List<StudentVo> getStudents() {
		return dao.getStudents();
	}

	

	public List<StudentVo> searchAttend(int studentID) {
		return dao.searchAttend(studentID);
	}

	public int updateStudent(int studentID, String gender, int age, String birth, String parentName,
			String name, String parentPhone, String special, String info, String home) throws Exception {
		return dao.updateStudent(studentID, gender, age, birth, parentName, name, parentPhone, special, info , home);
	}

	public List<StudentVo> searchAttend(String name) {
		return dao.searchAttend(name);
	}

	public List<StudentVo> searchDayAttend(int studentID) {
		return dao.searchDayAttend(studentID);
	}


	
}
