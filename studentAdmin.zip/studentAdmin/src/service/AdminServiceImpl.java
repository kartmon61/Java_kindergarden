package service;

import dao.AdminDao;

public class AdminServiceImpl implements AdminService{

	private  AdminDao dao = null;

	
	
	

	public AdminServiceImpl(AdminDao dao) {
		super();
		this.dao = dao;
	}

	public boolean checkLogIn(String adminID, String adminPW) {
		
		return dao.checkLogIn(adminID, adminPW);
	}

	public int insertAdmin(String adminID, String adminPW) {
		return dao.insertAdmin(adminID, adminPW);
	}

	public boolean checkpLogIn(String adminID, int studentID) {
		return dao.checkpLogIn(adminID, studentID);
	}
}
