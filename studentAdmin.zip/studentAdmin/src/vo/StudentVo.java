package vo;

public class StudentVo {
	private int studentID;
	private String attend;
	private String gender;
	private int age;
	private String birth;
	private String parentName;
	private String parentPhone;
	private String name;
	private String home;
	private String special;
	private String info;
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getAttend() {
		return attend;
	}
	public void setAttend(String attend) {
		this.attend = attend;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public StudentVo() {
		super();
	}
	public String getParentPhone() {
		return parentPhone;
	}
	public void setParentPhone(String parentPhone) {
		this.parentPhone = parentPhone;
	}
	public String getHome() {
		return home;
	}
	public void setHome(String home) {
		this.home = home;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getSpecial() {
		return special;
	}
	public void setSpecial(String special) {
		this.special = special;
	}
	public StudentVo(int studentID, String attend, String gender, int age, String birth, String parentName,
			String parentPhone, String name, String home, String special, String info) {
		super();
		this.studentID = studentID;
		this.attend = attend;
		this.gender = gender;
		this.age = age;
		this.birth = birth;
		this.parentName = parentName;
		this.parentPhone = parentPhone;
		this.name = name;
		this.home = home;
		this.special = special;
		this.info = info;
	}
	public String toString() {
		return "학생정보 [학생ID=" + studentID + ", 성별 =" + gender + ", 나이=" + age
				+ ", 생년월일 =" + birth + ", 부모님성함 =" + parentName + ", 부모님 휴대폰번호=" + parentPhone + ", 이름=" + name
				+ ", 주소=" + home + ", 특이사항=" + special + ", 기타정보=" + info + "]";
	}
	
	
}
