package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import util.JdbcUtil;

public class AdminDao {
	private Connection con = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	
	public int insertAdmin(String adminID, String adminPW) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int result = 0;
		String sql = 
				"insert into admin(adminID, adminPW) " +
				"values(?,?)";
		con = JdbcUtil.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, adminID);
			ps.setString(2, adminPW);
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "아이디 비밀번호를 확인하고 회원가입 ㄱㄱ");
		} finally {
			JdbcUtil.close(rs, ps, con);
		}
		
		return result;
	}
	
	public boolean checkLogIn(String adminID, String adminPW) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select * from admin";
		con = JdbcUtil.getConnection();
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				if(adminID.equals(rs.getString("adminID"))) {
					if(adminPW.equals(rs.getString("adminPW"))) return true;
				}
			}
			
		} catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs, ps, con);
		}
		
		
		return false;
	}
	public boolean checkpLogIn(String adminID, int studentID) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select * from student";
		con = JdbcUtil.getConnection();
		try {
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				if(adminID.equals(rs.getString("adminID"))) {
					if(studentID == rs.getInt("studentID")) return true;
				}
			}
			
		} catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs, ps, con);
		}
		
		
		return false;
	
	}
}
