package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import app.LoginGui;
import util.JdbcUtil;
import vo.StudentVo;

public class StudentDao {
	private Connection con = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;
	SimpleDateFormat date = new SimpleDateFormat("MM");
	SimpleDateFormat day = new SimpleDateFormat("dd");
	public int insertStudent(int studentID, String attend, String gender, int age, 
			String birth, String parentName, String name, String parentPhone, String special, String info, String home) throws Exception {

		int result = 0;
		String sql = 
				"insert into student (studentID, attend, gender, age, birth, parentName, parentPhone, name, adminID, special, info, home)\r\n" + 
						"values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		con = JdbcUtil.getConnection();
		ps = con.prepareStatement(sql);
		ps.setInt(1, studentID);
		ps.setString(2, attend);
		ps.setString(3, gender);
		ps.setInt(4, age);
		ps.setString(5, birth);
		ps.setString(6, parentName);
		ps.setString(7, parentPhone);
		ps.setString(8, name);
		ps.setString(9, LoginGui.adminID);
		ps.setString(10, special);
		ps.setString(11, info);
		ps.setString(12, home);

		result = ps.executeUpdate();


		JdbcUtil.close(rs, ps, con);

		return result;

	}
	public int deleteStudent(int studentID) {


		int result = 0;
		String sql = 
				"delete from student " +
						"where studentID = ? and adminID = ?";
		con = JdbcUtil.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, studentID);
			ps.setString(2, LoginGui.adminID);
			result = ps.executeUpdate();


		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			JdbcUtil.close(rs, ps, con);
		}

		return result;

	}
	public List<StudentVo> searchStudent(String name) {
		String sql = 
				"select * from student where lower(name) like ? and adminID = ? " + 
						"order by studentID";
		con = JdbcUtil.getConnection();
		StudentVo student = null;
		List<StudentVo> list = new ArrayList<StudentVo>();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, "%" + name.toLowerCase() + "%");
			ps.setString(2, LoginGui.adminID);
			rs = ps.executeQuery();

			while (rs.next()) {
				student = new StudentVo();
				student.setStudentID(rs.getInt("studentID"));
				student.setAttend(rs.getString("attend"));
				student.setGender(rs.getString("gender"));
				student.setAge(rs.getInt("age"));
				student.setBirth(rs.getString("birth"));
				student.setParentName(rs.getString("parentName"));
				student.setParentPhone(rs.getString("parentPhone"));
				student.setName(rs.getString("name"));
				student.setHome(rs.getString("home"));
				student.setSpecial(rs.getString("special"));
				student.setInfo(rs.getString("info"));
				list.add(student);
			}

		} catch (SQLException e) {
			
		} finally {
			JdbcUtil.close(rs, ps, con);
		}
		return list;
	}
	public StudentVo searchStudent(int studentID) {

		String sql = 
				"select * from student where studentID= ? and adminID = ? and attend = '0000/00/00' " + 
						"order by studentID";
		con = JdbcUtil.getConnection();
		StudentVo vo = null;
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, studentID);
			ps.setString(2, LoginGui.adminID);
			rs = ps.executeQuery();
			while(rs.next()) {
				vo = new StudentVo();
				vo.setStudentID(rs.getInt("studentID"));
				vo.setAttend(rs.getString("attend"));
				vo.setGender(rs.getString("gender"));
				vo.setAge(rs.getInt("age"));
				vo.setBirth(rs.getString("birth"));
				vo.setParentName(rs.getString("parentName"));
				vo.setName(rs.getString("name"));
				vo.setHome(rs.getString("home"));
				vo.setParentPhone(rs.getString("parentPhone"));
				vo.setSpecial(rs.getString("special"));
				vo.setInfo(rs.getString("info"));
			}


		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			JdbcUtil.close(rs, ps, con);
		}
		return vo;
	}
	public List<StudentVo> getStudents() {
		List<StudentVo> list = new ArrayList<StudentVo>();

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		StudentVo student = null;
		String sql = "select distinct * from student where adminID = ? and attend = '0000/00/00' order by studentID";
		con = JdbcUtil.getConnection();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, LoginGui.adminID);
			rs = ps.executeQuery();
			while (rs.next()) {
				student = new StudentVo();
				student.setStudentID(rs.getInt("studentID"));
				student.setAttend(rs.getString("attend"));
				student.setGender(rs.getString("gender"));
				student.setAge(rs.getInt("age"));
				student.setBirth(rs.getString("birth"));
				student.setParentName(rs.getString("parentName"));
				student.setName(rs.getString("name"));
				student.setHome(rs.getString("home"));
				student.setParentPhone(rs.getString("parentPhone"));
				student.setSpecial(rs.getString("special"));
				student.setInfo(rs.getString("info"));
				
				list.add(student);
			}

		} catch (SQLException e) {
			System.out.println("****");
			System.out.println(e.toString());
			System.out.println("****");
		} finally {
			JdbcUtil.close(rs, ps, con);
		}

		return list;

	}
	public int updateStudent(int studentID, String gender, int age, 
			String birth, String parentName, String name, String parentPhone, String special, String info, String home) throws Exception {
		int result = 0;
		String sql = 
				"update student set gender = ?, name =?, age = ?, birth = ?, parentName = ?, parentPhone = ?, special = ?, info = ?, home = ? " +
						"where studentID = ? and adminID = ?";
		con = JdbcUtil.getConnection();

		ps = con.prepareStatement(sql);
		ps.setString(1, gender);
		ps.setString(2, name);
		ps.setInt(3, age);
		ps.setString(4, birth);
		ps.setString(5, parentName);
		
		ps.setString(6, parentPhone);
		ps.setString(7, special);
		ps.setString(8, info);

		ps.setString(9, home);
		ps.setInt(10, studentID);
		ps.setString(11, LoginGui.adminID);
		

		result = ps.executeUpdate();




		return result;

	}
	public List<StudentVo> searchAttend(int studentID) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select * from student " + 
					"where studentID = ? and adminID = ? order by attend ";
		con = JdbcUtil.getConnection();
		StudentVo student = null;
		ArrayList<StudentVo> list = new ArrayList<>();
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, studentID);
			ps.setString(2, LoginGui.adminID);
			rs = ps.executeQuery();
			while (rs.next()) {
				student = new StudentVo();
				String[] spl = rs.getString("attend").split("/");
				if (spl[1].equals(date.format(new Date()))) {
					student.setAttend(rs.getString("attend"));
				}
				else continue;
				student.setStudentID(rs.getInt("studentID"));
				student.setGender(rs.getString("gender"));
				student.setAge(rs.getInt("age"));
				student.setBirth(rs.getString("birth"));
				student.setParentName(rs.getString("parentName"));
				student.setName(rs.getString("name"));
				student.setHome(rs.getString("home"));
				student.setParentPhone(rs.getString("parentPhone"));
				student.setSpecial(rs.getString("special"));
				student.setInfo(rs.getString("info"));
				
				list.add(student);
			}
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs, ps, con);
		}
		
		return list;
	}
	
	public List<StudentVo> searchAttend(String name) {
		String sql = 
				"select * from student where lower(name) like ? and adminID = ? " + 
						"order by studentID";
		con = JdbcUtil.getConnection();
		StudentVo student = null;
		List<StudentVo> list = new ArrayList<StudentVo>();
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, "%" + name.toLowerCase() + "%");
			ps.setString(2, LoginGui.adminID);
			rs = ps.executeQuery();

			while (rs.next()) {
				student = new StudentVo();
				String[] spl = rs.getString("attend").split("/");
				if (spl[1].equals(date.format(new Date()))) {
					student.setAttend(rs.getString("attend"));
				}
				else continue;
				student.setStudentID(rs.getInt("studentID"));
				student.setAttend(rs.getString("attend"));
				student.setGender(rs.getString("gender"));
				student.setAge(rs.getInt("age"));
				student.setBirth(rs.getString("birth"));
				student.setParentName(rs.getString("parentName"));
				student.setParentPhone(rs.getString("parentPhone"));
				student.setName(rs.getString("name"));
				student.setHome(rs.getString("home"));
				student.setSpecial(rs.getString("special"));
				student.setInfo(rs.getString("info"));
				list.add(student);
			}

		} catch (SQLException e) {
			System.out.println("****");
			System.out.println(e.toString());
			System.out.println("****");
		} finally {
			JdbcUtil.close(rs, ps, con);
		}
		return list;
	}
	
	public List<StudentVo> searchDayAttend(int studentID) {
		
		String sql = 
				"select * from student where studentID = ? and adminID = ? " + 
						"order by attend";
		con = JdbcUtil.getConnection();
		StudentVo student = null;
		List<StudentVo> list = new ArrayList<StudentVo>();
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, studentID);
			ps.setString(2, LoginGui.adminID);
			rs = ps.executeQuery();

			while (rs.next()) {
				student = new StudentVo();
				String[] spl = rs.getString("attend").split("/");
				if (spl[2].equals(day.format(new Date()))) {
					student.setAttend(rs.getString("attend"));
				}
				else continue;
				student.setStudentID(rs.getInt("studentID"));
				student.setAttend(rs.getString("attend"));
				student.setGender(rs.getString("gender"));
				student.setAge(rs.getInt("age"));
				student.setBirth(rs.getString("birth"));
				student.setParentName(rs.getString("parentName"));
				student.setParentPhone(rs.getString("parentPhone"));
				student.setName(rs.getString("name"));
				student.setHome(rs.getString("home"));
				student.setSpecial(rs.getString("special"));
				student.setInfo(rs.getString("info"));
				list.add(student);
			}

		} catch (SQLException e) {
			System.out.println("****");
			System.out.println(e.toString());
			System.out.println("****");
		} finally {
			JdbcUtil.close(rs, ps, con);
		}
		return list;
		
	}
}
